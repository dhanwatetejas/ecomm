import { EventEmitter, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router';
// import { SignUp } from '../dataType';
@Injectable({
  providedIn: 'root'
})
export class SellerService {
  isSellerLoggedIn = new BehaviorSubject<boolean>(false);
  isLoginError = new EventEmitter <boolean>(false);
  constructor(private http:HttpClient,private router:Router) { }
  userSignUp(data:any){
   return this.http.post('http://localhost:3000/seller',data,{observe:'response'}).subscribe((result)=>{
     this.isSellerLoggedIn.next(true);
     localStorage.setItem('seller',JSON.stringify(result.body))
     this.router.navigate(['sellerHome'])
    //  console.log('result',result);
   });
  }
   reloadSeller(){
     if(localStorage.getItem('seller')){
     this.isSellerLoggedIn.next(true);
     this.router.navigate(['sellerHome']);
    }
  }
  userLogin(data:any){
    console.log(data);
    return this.http.get(`http://localhost:3000/seller?email=${data.email}&password=${data.password}`,
    {observe:'response'}).subscribe((result:any)=>{
      console.log(result);
      if(result && result.body && result.body.length){
        console.log('User Logged In ');
        localStorage.setItem('seller',JSON.stringify(result.body))
        this.router.navigate(['sellerHome'])
        
      }
      else{ console.log('Failed Log In');
      this.isLoginError.emit(true);
    }
      
    })
    
       
  }
}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
  addProduct(data:any){
    console.log("form Data is",data);
    this.http.post("http://localhost:3000/products",data).subscribe((res)=>{
console.log("res is",res);

    })
    
  }
  productListing(){
    return this.http.get("http://localhost:3000/products")
  }
  deleteProduct(id:any){
    return this.http.delete(`http://localhost:3000/products/${id}`)

  }
}

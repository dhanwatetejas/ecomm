import { Component } from '@angular/core';
import { FormGroup,FormControl,Validators } from '@angular/forms';
import { SellerService } from '../services/seller.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-seller-auth',
  templateUrl: './seller-auth.component.html',
  styleUrl: './seller-auth.component.css'
})
export class SellerAuthComponent {
  showLogin=false;
  authError:string='';
  signupForm= new FormGroup({
    name:new FormControl(''),
    password:new FormControl(''),
    email:new FormControl('')
  })

  loginForm= new FormGroup({
    email:new FormControl(''),
    password:new FormControl('')
    
  })

  constructor(private seller:SellerService,private router:Router){}

  ngOnInit(){
    this.seller.reloadSeller()
  }
  submitSignUp(){
    // console.log(this.signupForm.value);
    this.seller.userSignUp(this.signupForm.value)
    
  }
  openLogin(){
    this.showLogin=true;
  }
  openSignUp(){
    this.showLogin=false;
  }

  submitLogin(){
    if(this.loginForm.value.email && this.loginForm.value.password){
    this.authError ='';
    // console.log(this.loginForm.value);
    this.seller.userLogin(this.loginForm.value);
    this.seller.isLoginError.subscribe((isError)=>{
      if(isError){
        this.authError='Wrong Credentials';
      }
    })
    
  }
  else{
    this.authError ='Both fields required';
  }
}
}

import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { ProductService } from '../services/product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-seller-add-product',
  templateUrl: './seller-add-product.component.html',
  styleUrl: './seller-add-product.component.css'
})
export class SellerAddProductComponent {
  productStatus:string=''
  constructor(private productService:ProductService,private route:Router){}
  addProductForm=new FormGroup({
    name:new FormControl(''),
    price:new FormControl(''),
    category:new FormControl(''),
    description:new FormControl(''),
    color:new FormControl(''),
    image:new FormControl('')

  })
  addProduct(){
    
    this.productService.addProduct(this.addProductForm.value);
    this.route.navigate(['sellerHome']);
    this.productStatus='Product added successfully'

    
  }

}

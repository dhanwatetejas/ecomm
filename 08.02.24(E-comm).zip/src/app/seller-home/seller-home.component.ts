import { Component } from '@angular/core';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-seller-home',
  templateUrl: './seller-home.component.html',
  styleUrl: './seller-home.component.css'
})
export class SellerHomeComponent {
  productData:any;
  productStatus:string='';
  constructor(private productService:ProductService){}
  ngOnInit(){
    this.list();
      

      
    

  }
  list(){
    this.productService.productListing().subscribe((res)=>{
      console.log("This is result=",res);
      this.productData=res;
    })

  }
  deleteItem(data:any){
    console.log("Id is =", data);
    this.productService.deleteProduct(data).subscribe((res)=>{
      console.log("res is =",res);
      this.productStatus='Product is deleted'
      this.list();
    })
    
    setTimeout(()=>{
      this.productStatus=''
    },3000)
  }

}
